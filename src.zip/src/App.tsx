import { useState } from 'react';
import './App.css';
import Sidebar from './components/Sidebar';
import Canvas from './components/Canvas';
import PropertiesPanel from './components/PropertiesPanel';
import type { CircuitComponent, Wire } from './types';
import { generateNetlist } from './utils/netlist';
import { getEngine } from '@/lib/circuitEngine';
import type { SimulationResult } from '@/lib/circuitEngine';
import { CircuitEngine } from '@/lib/circuitEngine';

export default function App() {
  const [components, setComponents] = useState<CircuitComponent[]>([]);
  const [wires, setWires] = useState<Wire[]>([]);
  const [selectedComponent, setSelectedComponent] = useState<CircuitComponent | null>(null);
  const [selectedWire, setSelectedWire] = useState<string | null>(null);
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  // ── Simulation state ───────────────────────────────────────────
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [consoleLines, setConsoleLines] = useState<string[]>([]);

  function log(line: string) {
    setConsoleLines(prev => [...prev, line]);
  }

  function updateComponent(updated: CircuitComponent) {
    setComponents(prev => prev.map(c => c.uuid === updated.uuid ? updated : c));
    setSelectedComponent(updated);
  }

  function deleteSelectedComponent() {
    if (!selectedComponent) return;
    setComponents(prev => prev.filter(c => c.uuid !== selectedComponent.uuid));
    setSelectedComponent(null);
  }

  function deleteSelectedWire() {
    if (!selectedWire) return;
    setWires(prev => prev.filter(w => w.id !== selectedWire));
    setSelectedWire(null);
  }

  async function runSimulation() {
    const netlist = generateNetlist(components, wires);
    setConsoleOpen(true);
    setConsoleLines([]);
    setLoading(true);

    log('> Running simulation...');
    log('> Netlist:');
    netlist.split('\n').forEach(l => log('  ' + l));
    log('');

    try {
      const engine = await getEngine();
      const res = engine.simulate(netlist);
      setResult(res);

      if (!res.success) {
        log('✗ Error: ' + res.error_msg);
      } else {
        log(`✓ Analysis: ${res.analysis_type.toUpperCase()} — ${res.data.length} point(s)`);
        log('');

        if (res.analysis_type === 'op') {
          log('── Node Voltages ──');
          CircuitEngine.voltages(res).forEach(v =>
            log(`  V(${v.name}) = ${v.real.toFixed(6)} V`)
          );
          log('── Branch Currents ──');
          CircuitEngine.currents(res).forEach(c =>
            log(`  I(${c.name}) = ${(c.real * 1000).toFixed(6)} mA`)
          );
        }

        else if (res.analysis_type === 'tran') {
          const nodes = res.data[0].values.filter(v => v.type === 'voltage').map(v => v.name);
          log('── Transient (sampled 20 pts) ──');
          log('  Time(ms)'.padEnd(14) + nodes.map(n => `V(${n})`.padEnd(14)).join(''));
          const step = Math.max(1, Math.floor(res.data.length / 20));
          res.data.filter((_, i) => i % step === 0).forEach(pt => {
            const t = (pt.sweep_value * 1000).toFixed(3).padEnd(14);
            const vals = nodes.map(name => {
              const nv = pt.values.find(v => v.name === name);
              return (nv ? nv.real.toFixed(4) : '-').padEnd(14);
            }).join('');
            log('  ' + t + vals);
          });
        }

        else if (res.analysis_type === 'dc') {
          const nodes = res.data[0].values.filter(v => v.type === 'voltage').map(v => v.name);
          log('── DC Sweep (sampled 20 pts) ──');
          log('  Sweep(V)'.padEnd(14) + nodes.map(n => `V(${n})`.padEnd(14)).join(''));
          const step = Math.max(1, Math.floor(res.data.length / 20));
          res.data.filter((_, i) => i % step === 0).forEach(pt => {
            const s = pt.sweep_value.toFixed(3).padEnd(14);
            const vals = nodes.map(name => {
              const nv = pt.values.find(v => v.name === name);
              return (nv ? nv.real.toFixed(4) : '-').padEnd(14);
            }).join('');
            log('  ' + s + vals);
          });
        }

        else if (res.analysis_type === 'ac') {
          const nodes = res.data[0].values.filter(v => v.type === 'voltage').map(v => v.name);
          log('── AC Bode (sampled 20 pts) ──');
          log('  Freq(Hz)'.padEnd(14) + nodes.map(n => `|V(${n})| dB`.padEnd(16)).join(''));
          const step = Math.max(1, Math.floor(res.data.length / 20));
          res.data.filter((_, i) => i % step === 0).forEach(pt => {
            const f = pt.sweep_value.toFixed(1).padEnd(14);
            const vals = nodes.map(name => {
              const nv = pt.values.find(v => v.name === name);
              if (!nv) return '-'.padEnd(16);
              const db = 20 * Math.log10(Math.sqrt(nv.real ** 2 + nv.imag ** 2) || 1e-30);
              return db.toFixed(2).padEnd(16);
            }).join('');
            log('  ' + f + vals);
          });
        }
      }
    } catch (e: any) {
      log('✗ Exception: ' + e.message);
    } finally {
      setLoading(false);
      log('');
      log('> Done.');
    }
  }

  return (
    <div className="app">
      <Sidebar selectedTool={selectedTool} setSelectedTool={setSelectedTool} />

      <div style={{ flex: 1, minWidth: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column', position: 'relative' }}>
        <Canvas
          components={components}
          wires={wires}
          selectedComponent={selectedComponent}
          selectedWire={selectedWire}
          selectedTool={selectedTool}
          setSelectedTool={setSelectedTool}
          setComponents={setComponents}
          setWires={setWires}
          setSelectedComponent={setSelectedComponent}
          setSelectedWire={setSelectedWire}
        />

        {/* ── Run button nổi trên Canvas ── */}
        <button
          onClick={runSimulation}
          disabled={loading}
          style={{
            position: 'absolute',
            bottom: 16,
            left: '50%',
            transform: 'translateX(-50%)',
            padding: '8px 28px',
            background: loading ? '#555' : '#2563eb',
            color: '#fff',
            border: 'none',
            borderRadius: 8,
            fontWeight: 600,
            fontSize: 14,
            cursor: loading ? 'not-allowed' : 'pointer',
            zIndex: 10,
            boxShadow: '0 2px 8px rgba(0,0,0,0.4)',
          }}
        >
          {loading ? 'Simulating...' : '▶ Run Simulation'}
        </button>

        {/* ── Console drawer overlay ── */}
        {consoleOpen && (
          <div style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            height: '40%',
            background: '#0f1117',
            borderTop: '2px solid #2563eb',
            display: 'flex',
            flexDirection: 'column',
            zIndex: 20,
          }}>
            {/* Header */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '4px 12px',
              background: '#1a1d27',
              borderBottom: '1px solid #2a2d3a',
            }}>
              <span style={{ color: '#90caf9', fontWeight: 600, fontSize: 13 }}>
                ● Console
              </span>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={() => setConsoleLines([])}
                  style={{ background: 'none', border: 'none', color: '#666', cursor: 'pointer', fontSize: 12 }}
                >
                  Clear
                </button>
                <button
                  onClick={() => setConsoleOpen(false)}
                  style={{ background: 'none', border: 'none', color: '#666', cursor: 'pointer', fontSize: 16 }}
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Output */}
            <pre style={{
              flex: 1,
              margin: 0,
              padding: '8px 14px',
              overflowY: 'auto',
              fontFamily: 'monospace',
              fontSize: 12,
              color: '#e0e0e0',
              lineHeight: 1.6,
              whiteSpace: 'pre',
            }}>
              {consoleLines.map((line, i) => {
                const color =
                  line.startsWith('✓') ? '#66bb6a' :
                  line.startsWith('✗') ? '#ef5350' :
                  line.startsWith('>') ? '#90caf9' :
                  line.startsWith('──') ? '#ffa726' :
                  '#e0e0e0';
                return <div key={i} style={{ color }}>{line || '\u00a0'}</div>;
              })}
            </pre>
          </div>
        )}
      </div>

      <div className="rightPanel">
        <PropertiesPanel
          selected={selectedComponent}
          onUpdate={updateComponent}
          onDelete={deleteSelectedComponent}
        />
        <div className="netlistPanel">
          <h3>Netlist</h3>
          <textarea value={generateNetlist(components, wires)} readOnly />
          <button onClick={deleteSelectedWire}>Delete Wire</button>
        </div>
      </div>
    </div>
  );
}